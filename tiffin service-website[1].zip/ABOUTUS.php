<?php
// ABOUTUS.php — Placeholder
echo "<h1>About Us</h1><p>This is a sample About Us page.</p>";
?>