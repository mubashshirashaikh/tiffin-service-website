<?php
echo "<h1>Bill Page (Bill4.php)</h1>";
?>