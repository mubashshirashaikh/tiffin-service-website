<html lang="en">
 <head> ... </head>
 <body>Menu2 content here...</body>
</html>